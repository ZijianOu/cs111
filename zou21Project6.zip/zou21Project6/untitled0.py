# -*- coding: utf-8 -*-
"""
Created on Mon Dec  2 17:46:03 2019

@author: ouzij
"""

import pandas as pd
import matplotlib.pyplot as plt
import geopandas as gpd

fileref = open('Crimes_-_2012_to_present.csv', encoding = 'ISO-8859-1')
df = pd.read_csv(fileref)
communities = gpd.read_file('Boundaries_Community.geojson')

def com_count(df, col, value, unique_id, com_num):
    """Returns count of unique_id in df com_num rows w/entry value in column col"""
    rows = df[df[col] == value] # boolean slice of rows we want
    if com_num not in rows['Community Area'].values:
        return 0
    grouped = rows.groupby('Community Area')
    return grouped[unique_id].count()[com_num]

def make_dictionary(df, col, value, unique_id):
    new_dict = {}
    for i in range(77):
        a = com_count(df, col, value, unique_id, i)
        new_dict[i] = a
    return new_dict

ls=make_dictionary(df, 'Primary Type', 'HOMICIDE', 'Case Number')
#communites[area_num_1] us equal to some variable
areas = communities['area_num_1']
lst1=[]
for i in range(77):
    i = int(i)
    lst1.append(ls[i])
#loop through the variable (which will be a list)
#access value in dictionary, append to new  list
communities['Total']=lst1


fig, ax = plt.subplots() # gives back tuple of figue, axes
fig.set_size_inches (10, 10) # Just controls size; try other numbers
communities.plot(column='Total', scheme='quantiles',
edgecolor='black', ax=ax, legend=True)
plt.title('Heatmap of HOMICIDE in 77 communities')
plt.savefig('plt1.png')
#for key in ls:
#    print("this is the FIRST plot", ls[key])

def make_dictionary1(df, col, value, unique_id):
    new_dict1 = {}
    for i in range(77):
        a = com_count(df, col, value, unique_id, i)
        new_dict1[i] = a
    return new_dict1

ls=make_dictionary1(df, 'Primary Type', 'NARCOTICS', 'Case Number')
q=list(ls.values())
#mx = max(list(ls.values()))
lst2=[]
for i in range(77):
    i = int(i)
    lst2.append(ls[i])
    
communities['Total']=lst2
fig, ax = plt.subplots() # gives back tuple of figue, axes
fig.set_size_inches (10, 10) # Just controls size; try other numbers
communities.plot(column='Total', scheme='equalinterval',
edgecolor='black', ax=ax, legend=True, k=8)
plt.title('Heatmap of NARCOTICS in 77 communities')
plt.savefig('plt2.png')

#for key in ls:
#    print("this is the SECOND plot", ls[key])

def make_dictionary2(df, col, value, unique_id):
    new_dict2 = {}
    for i in range(77):
        a = com_count(df, col, value, unique_id, i)
        new_dict2[i] = a
    return new_dict2

ls=make_dictionary2(df, 'Primary Type', 'ASSAULT', 'Case Number')
w=list(ls.values())
mx1 = max(q)
lst1=[]
for i in range(77):
    i = int(i)
    lst1.append(ls[i]/mx1)
print(mx1)
mx2 = max(w)
lst2=[]
for i in range(77):
    i = int(i)
    lst2.append(ls[i]/mx2)
print(mx2)

lst3=[]
for i in range (77):
    sum_values = lst1[i]+lst2[i]
    lst3.append(sum_values)
communities['Total2']=lst3
fig, ax = plt.subplots() # gives back tuple of figue, axes
fig.set_size_inches (10, 10) # Just controls size; try other numbers
communities.plot(column='Total', scheme='equalinterval',
edgecolor='black', ax=ax, legend=True, k=10)
plt.title('Scaled heatmap of ASSAULT in 77 communities')
plt.savefig('plt3.png')























