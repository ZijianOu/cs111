# -*- coding: utf-8 -*-
"""
Created on Thu Nov 21 11:22:03 2019

@author: ouzij
"""

import matplotlib.pyplot as plt
import pandas
import networkx as nx
import numpy
fileref = open('twitter_cleaned.csv', encoding = 'ISO-8859-1')
scdb = pandas.read_csv(fileref)
 
file = open("NetworkLab", 'w')

g = nx.Graph()

g.add_edges_from(scdb.values)
nodes = g.number_of_nodes()
edges = g.number_of_edges()

degree_data = pandas.Series(dict(nx.degree(g)))

file.write(str(scdb.head()) + '\n\n')
file.write("Edges:" + str(edges) + "\n")
file.write("Nodes:" + str(nodes) + "\n\n")
file.write("Degree data: " + str(degree_data.sort_values(ascending=False).head(10)))

f = plt.figure(1)
figsize=(8,6)
degree_data.plot(kind='hist')
plt.title('Degree Distribution (no scaling)')
plt.xlabel('Degree')
plt.ylabel('Count')
plt.savefig('1.png')
#f = plt.figure(figsize=(8,6))




f2 = plt.figure(2)
figsize=(8,6)
degree_data = pandas.Series(dict(nx.degree(g)))
#degree_data.plot(kind='hist')
f2 = numpy.log10(degree_data)
f2.plot(kind='hist')
plt.title('Distribution of log base 10 of degrees')
plt.xlabel('Log base 10 of degree')
plt.ylabel('Count')
plt.savefig('2.png')
#f = plt.figure(figsize=(8,6))

cent_node = nx.degree_centrality(g)
central_edge = pandas.Series(dict(cent_node)).sort_values(ascending=False).head(10)
print(central_edge)
only_james = cent_node['James']
print("james value = ", only_james)

g_cored = nx.k_core(g, 3)
#edge_data = pandas.read_csv('twitter_cleaned.csv', encoding = 'ISO-8859-1')
degree_data = pandas.Series(dict(nx.degree(g_cored)))
#log_degree = numpy.log10(degree_data)
plt.figure('plot3')
degree_data.plot(kind='hist')
plt.title("3-cored graph degree distribution")
plt.xlabel("Degree")
plt.ylabel("Count")
plt.savefig('3.png')
plt.show()

list_cored = list(g_cored.nodes())
#print(list_cored)
for i in list_cored:
    if type(i)==str:
        if len(i)>=9:
            i=i[0:7]+'.'
#    print(i)
dictionary = {}
dictionary = list_cored
#print(dictionary)
nx.draw_networkx(g_cored, with_labels=True, labela = dictionary, font_size=8)
plt.savefig('4.png')


fileref1 = open('musae_ENGB_edges.csv', encoding = 'ISO-8859-1')
tw = pandas.read_csv(fileref1)
#file = open("NetworkLab", 'w')

g2 = nx.Graph()

g2.add_edges_from(tw.values)
twitch_nodes = g2.number_of_nodes()
twitch_edges = g2.number_of_edges()

degree_data1 = pandas.Series(dict(nx.degree(g2)))

file.write(str(tw.head()) + '\n\n')
file.write("Edges:" + str(twitch_edges) + "\n")
file.write("Nodes:" + str(twitch_nodes) + "\n\n")
file.write("Degree data: " + str(degree_data1.sort_values(ascending=False).head(10)))

f4 = plt.figure(4)
figsize=(8,6)
degree_data1.plot(kind='hist')
plt.title('Twitch Degree Distribution (no scaling)')
plt.xlabel('DegreeTwitch')
plt.ylabel('CountTwitch')
plt.savefig('5.png')

f5 = plt.figure(5)
figsize=(8,6)
degree_data1 = pandas.Series(dict(nx.degree(g2)))
#degree_data.plot(kind='hist')
f2 = numpy.log10(degree_data1)
f2.plot(kind='hist')
plt.title('Twitch Distribution of log base 10 of degrees')
plt.xlabel('Twitch Log base 10 of degree')
plt.ylabel('Count Twitch')
plt.savefig('6.png')

g2_cored = nx.k_core(g2, 3)
#edge_data = pandas.read_csv('twitter_cleaned.csv', encoding = 'ISO-8859-1')
degree_data = pandas.Series(dict(nx.degree(g2_cored)))
#log_degree = numpy.log10(degree_data)
plt.figure('plot6')
degree_data.plot(kind='hist')
plt.title("Twitch 3-cored graph degree distribution")
plt.xlabel("DegreeTwitch")
plt.ylabel("CountTwitch")
plt.savefig('7.png')
plt.show()

list_cored2 = list(g2_cored.nodes())
#print(list_cored)
#for i in list_cored2:
#    if type(i)==str:
#        if len(i)>=9:
#            i=i[0:7]+'.'
#    print(i)
dictionary = {}
dictionary = list_cored2
#print(dictionary)
nx.draw_networkx(g2_cored, with_labels=True, labela = dictionary, font_size=8)
plt.savefig('8.png')
"""for 8.png, we can see that there are so many elements in the file, and so many
different connections, as a twitch user, I find it really fascinating."""